"""
Unit tests for UPID CLI
""" 