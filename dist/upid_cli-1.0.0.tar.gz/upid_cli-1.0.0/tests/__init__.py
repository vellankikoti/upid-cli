"""
UPID CLI Test Suite
""" 