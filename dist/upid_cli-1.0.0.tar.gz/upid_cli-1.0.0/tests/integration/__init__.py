"""
Integration tests for UPID CLI using testcontainers
""" 